// services/pdf_service.dart

import 'dart:io';
import 'dart:typed_data';
import 'package:syncfusion_flutter_pdf/pdf.dart';
import '../utils/text_cleaner.dart';

class PDFService {
  /// Carga un archivo PDF desde el path dado y retorna el texto limpio por página
  static Future<List<String>> cargarPDF(String path) async {
    File file = File(path);
    Uint8List bytes = await file.readAsBytes();

    PdfDocument document = PdfDocument(inputBytes: bytes);
    PdfTextExtractor extractor = PdfTextExtractor(document);

    List<String> paginas = [];
    for (int i = 0; i < document.pages.count; i++) {
      String texto = extractor.extractText(
        startPageIndex: i,
        endPageIndex: i,
      );
      paginas.add(limpiarTexto(texto));
    }

    document.dispose();
    return paginas;
  }
}