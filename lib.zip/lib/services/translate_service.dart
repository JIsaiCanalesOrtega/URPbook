import 'dart:convert';
import 'package:http/http.dart' as http;
import '../services/connection_service.dart';

class TranslateService {
  final int batchSize;
  final int maxCharsPerBlock = 3000;

  TranslateService({this.batchSize = 2});

  /// Traduce un solo texto usando el endpoint gratuito de Google Translate
  Future<String> traducirTexto(String texto, String origen, String destino) async {
    try {
      final uri = Uri.parse(
        'https://translate.googleapis.com/translate_a/single?client=gtx&sl=$origen&tl=$destino&dt=t&q=${Uri.encodeComponent(texto)}',
      );

      final response = await http.get(uri);

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        return (data[0] as List).map((e) => e[0]).join();
      } else {
        return 'Error en la traducción: ${response.statusCode}';
      }
    } catch (e) {
      return 'Error de conexión: $e';
    }
  }

  /// Traduce una lista de textos por lotes con agrupación inteligente
  Future<List<String>> traducirPorLotes(
    List<String> textos,
    String origen,
    String destino,
    void Function(int count)? onProgress,
  ) async {
    if (!await ConnectionService.verificarConexion()) {
      throw Exception('No hay conexión a Internet');
    }

    List<String> resultado = List.from(textos);
    List<String> bloques = [];
    List<List<int>> bloquesAPaginas = [];

    String buffer = '';
    List<int> paginasEnEsteBloque = [];

    for (int i = 0; i < textos.length; i++) {
      final texto = textos[i];
      if ((buffer + texto).length > maxCharsPerBlock) {
        bloques.add(buffer);
        bloquesAPaginas.add(List.from(paginasEnEsteBloque));
        buffer = '';
        paginasEnEsteBloque.clear();
      }
      buffer += texto + '\n';
      paginasEnEsteBloque.add(i);
    }

    if (buffer.isNotEmpty) {
      bloques.add(buffer);
      bloquesAPaginas.add(paginasEnEsteBloque);
    }

    final traducciones = await Future.wait(
      bloques.map((bloque) async {
        try {
          return await traducirTexto(bloque, origen, destino);
        } catch (e) {
          return 'Error al traducir este bloque';
        }
      }),
    );

    for (int b = 0; b < traducciones.length; b++) {
      final paginasDelBloque = bloquesAPaginas[b];
      final partes = _dividirPorSaltos(traducciones[b], paginasDelBloque.length);

      for (int i = 0; i < paginasDelBloque.length; i++) {
        resultado[paginasDelBloque[i]] = partes[i];
        if (onProgress != null) onProgress(paginasDelBloque[i] + 1);
      }
    }

    return resultado;
  }

  /// Divide texto traducido en partes aproximadamente iguales por líneas
  List<String> _dividirPorSaltos(String texto, int partes) {
    final lineas = texto.split('\n');
    final bloques = List.generate(partes, (_) => '');

    for (int i = 0; i < lineas.length; i++) {
      final index = i % partes;
      bloques[index] += lineas[i] + '\n';
    }

    return bloques.map((b) => b.trim()).toList();
  }
}
