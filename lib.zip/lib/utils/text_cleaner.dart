// utils/text_cleaner.dart

/// Limpia y normaliza el texto extraído de un PDF.
String limpiarTexto(String texto) {
  if (texto.isEmpty) return '';

  texto = texto
      .replaceAll(RegExp(r'[“”„«»]'), '"')
      .replaceAll(RegExp(r'[’‘`´]'), "'")
      .replaceAll(RegExp(r'[–—]'), '-')
      .replaceAll('…', '...')
      .replaceAll(RegExp(r'[•·●▪‣⁃◦⦿⁕⁜⁎⁂]'), '• ')
      .replaceAll(RegExp(r'[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]'), '')
      .replaceAll('\r\n', '\n').replaceAll('\r', '\n')
      .replaceAll(RegExp(r'\n\s*\d+\s*\n'), '\n')
      .replaceAll(RegExp(r'\n\s*[Pp](ágina|age)\s+\d+.*?\n'), '\n')
      .replaceAll(RegExp(r'\n\s*\d+\s*(de|of|/)\s*\d+\s*\n'), '\n')
      .replaceAll(RegExp(r'[Pp](ágina|age)\s+\d+'), '')
      .replaceAll(RegExp(r'\n\s*(Capítulo|Chapter)\s+\d+\s*\n'), '\n');

  texto = texto.replaceAllMapped(RegExp(r'(\w+)-\s*\n\s*(\w+)'), (m) => '${m[1]}${m[2]}');
  texto = texto.replaceAllMapped(RegExp(r'([a-zA-ZáéíóúüñÁÉÍÓÚÜÑ])\s*\n\s*([a-zA-ZáéíóúüñÁÉÍÓÚÜÑ])'), (m) {
    String a = m[1]!;
    String b = m[2]!;
    return b[0].toLowerCase() == b[0] ? '$a$b' : '$a $b';
  });

  texto = texto.replaceAllMapped(RegExp(r'([a-záéíóúüñ,;:])\s*\n\s*([a-záéíóúüñ])'), (m) => '${m[1]} ${m[2]}');
  texto = texto.replaceAllMapped(RegExp(r'([.!?:])\s*\n'), (m) => '${m[1]}\n\n');

  texto = texto.replaceAll(RegExp(r' +'), ' ')
                 .replaceAll(RegExp(r'\n{3,}'), '\n\n')
                 .replaceAll(RegExp(r' +([,.!?;:])'), r'$1')
                 .replaceAll(RegExp(r'([,.!?;:])([^\s\d])'), r'$1 $2');

  texto = texto
      .replaceAll(RegExp(r'\bl\b'), 'I')
      .replaceAll(RegExp(r'\b0\b'), 'O')
      .replaceAll('c1ue', 'que')
      .replaceAll('cl ', 'el ')
      .replaceAll('rn', 'm')
      .replaceAll('|', 'l')
      .replaceAll('¡', 'i');

  List<String> lineas = texto.split('\n');
  List<String> limpias = [];

  for (String linea in lineas) {
    String trim = linea.trim();
    if (trim.isEmpty ||
        RegExp(r'^\d+\$').hasMatch(trim) ||
        RegExp(r'^[A-Z\s]{3,}\$').hasMatch(trim) ||
        trim.length < 3) continue;
    limpias.add(linea);
  }

  return limpias.join('\n').trim();
}