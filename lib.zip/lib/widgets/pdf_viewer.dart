// widgets/pdf_viewer.dart

import 'package:flutter/material.dart';

class PDFViewer extends StatelessWidget {
  final String texto;
  final double fontSize;
  final double scaleFactor;
  final void Function(double newScale)? onZoomChanged;

  const PDFViewer({
    super.key,
    required this.texto,
    required this.fontSize,
    required this.scaleFactor,
    this.onZoomChanged,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onScaleUpdate: (details) {
        if (onZoomChanged != null) {
          onZoomChanged!(scaleFactor * details.scale);
        }
      },
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Text(
          texto,
          style: TextStyle(
            fontSize: fontSize,
            height: 1.5,
            letterSpacing: 0.3,
          ),
          textAlign: TextAlign.justify,
        ),
      ),
    );
  }
}
// This widget displays a PDF-like text viewer with zoom functionality.