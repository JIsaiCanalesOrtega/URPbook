// screens/home_screen.dart

import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../services/pdf_service.dart';
import '../services/translate_service.dart';
import '../utils/storage_helper.dart';
import '../utils/cache_helper.dart';
import '../widgets/pdf_viewer.dart';
import '../widgets/translate_controls.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<String> paginas = [];
  List<String> paginasOriginales = [];
  int paginaActual = 0;

  bool isLoading = false;
  bool isTranslating = false;
  bool mostrarRecientes = true;
  bool documentoTraducido = false;

  double fontSize = 18.0;
  double initialFontSize = 18.0;
  double scaleFactor = 1.0;

  List<String> archivosRecientes = [];
  String? archivoActual;

  int paginasTraducidas = 0;

  final TranslateService _translator = TranslateService();

  @override
  void initState() {
    super.initState();
    _cargarArchivosRecientes();
  }

  Future<void> _cargarArchivosRecientes() async {
    final recientes = await StorageHelper.cargarArchivosRecientes();
    setState(() {
      archivosRecientes = recientes;
    });
  }

  Future<void> _cargarPDF({String? path}) async {
    setState(() {
      isLoading = true;
      paginas = [];
      paginasOriginales = [];
      documentoTraducido = false;
    });

    try {
      if (path == null) {
        FilePickerResult? result = await FilePicker.platform.pickFiles(
          type: FileType.custom,
          allowedExtensions: ['pdf'],
        );

        if (result != null && result.files.single.path != null) {
          path = result.files.single.path!;
          archivoActual = path.split('/').last;
          await StorageHelper.agregarArchivoReciente(archivosRecientes, path);
        } else {
          setState(() {
            isLoading = false;
            mostrarRecientes = true;
          });
          return;
        }
      }

      if (path != null) {
        archivoActual = path.split('/').last;
        paginas = await PDFService.cargarPDF(path);
        paginasOriginales = List.from(paginas);
        await StorageHelper.agregarArchivoReciente(archivosRecientes, path);
      }
    } catch (e) {
      paginas = ['Error al cargar el PDF: $e'];
    }

    setState(() {
      isLoading = false;
      mostrarRecientes = false;
      paginaActual = 0;
      scaleFactor = 1.0;
      fontSize = initialFontSize;
    });
  }

  Future<void> _traducirDocumento() async {
    setState(() {
      isTranslating = true;
      paginasTraducidas = 0;
    });

    try {
      final origen = 'auto';
      final destino = 'es';

      final textos = documentoTraducido ? paginasOriginales : paginas;

      final hash = CacheHelper.generarHash(paginasOriginales);
      final cache = await CacheHelper.cargarTraduccion(hash);

      if (cache != null) {
        setState(() {
          paginas = cache;
          documentoTraducido = true;
          paginaActual = 0;
          isTranslating = false;
        });
        return;
      }

      final traducidas = await _translator.traducirPorLotes(
        textos,
        origen,
        destino,
        (count) {
          setState(() {
            paginasTraducidas = count;
          });
        },
      );

      setState(() {
        paginasOriginales = List.from(paginas);
        paginas = traducidas;
        documentoTraducido = true;
        paginaActual = 0;
      });

      await CacheHelper.guardarTraduccion(hash, traducidas);

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Traducción completada (${paginas.length} páginas)'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error de traducción: $e')),
      );
    }

    setState(() {
      isTranslating = false;
    });
  }

  void _alternarTraduccion() {
    if (documentoTraducido && paginasOriginales.isNotEmpty) {
      setState(() {
        final temp = paginas;
        paginas = paginasOriginales;
        paginasOriginales = temp;
        documentoTraducido = !documentoTraducido;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final texto = paginas.isNotEmpty ? paginas[paginaActual] : '';

    return Scaffold(
      appBar: AppBar(
        title: Text(archivoActual ?? 'ULB PDF Translator'),
        actions: [
          if (documentoTraducido && paginasOriginales.isNotEmpty)
            IconButton(
              icon: Icon(Icons.translate),
              onPressed: _alternarTraduccion,
              tooltip: 'Alternar traducción',
            ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : isTranslating
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 16),
                      Text('Traduciendo: $paginasTraducidas / ${paginas.length}'),
                    ],
                  ),
                )
              : paginas.isEmpty
                  ? const Center(child: Text('Carga un PDF para comenzar.'))
                  : PDFViewer(
                      texto: texto,
                      fontSize: fontSize,
                      scaleFactor: scaleFactor,
                      onZoomChanged: (newScale) {
                        setState(() {
                          scaleFactor = newScale.clamp(0.5, 3.0);
                          fontSize = (initialFontSize * scaleFactor).clamp(10.0, 60.0);
                        });
                      },
                    ),
      floatingActionButton: TranslateControls(
        isTranslating: isTranslating,
        mostrarRecientes: mostrarRecientes,
        isLoading: isLoading,
        documentoTraducido: documentoTraducido,
        paginaActual: paginaActual,
        totalPaginas: paginas.length,
        onTraducir: _traducirDocumento,
        onCargarPDF: _cargarPDF,
        onAnterior: paginaActual > 0
            ? () => setState(() => paginaActual--)
            : null,
        onSiguiente: paginaActual < paginas.length - 1
            ? () => setState(() => paginaActual++)
            : null,
        onResetZoom: () => setState(() {
          scaleFactor = 1.0;
          fontSize = initialFontSize;
        }),
        onZoomIn: () => setState(() {
          scaleFactor = (scaleFactor + 0.1).clamp(0.5, 3.0);
          fontSize = (initialFontSize * scaleFactor).clamp(10.0, 60.0);
        }),
        onZoomOut: () => setState(() {
          scaleFactor = (scaleFactor - 0.1).clamp(0.5, 3.0);
          fontSize = (initialFontSize * scaleFactor).clamp(10.0, 60.0);
        }),
      ),
    );
  }
}
// Este código es parte de una aplicación Flutter que permite cargar, traducir y visualizar documentos PDF. La pantalla principal (`HomeScreen`) maneja la carga de archivos, la traducción de texto y la visualización del contenido del PDF. Utiliza servicios para manejar PDFs y traducciones, así como utilidades para almacenamiento y caché. Además, incluye controles para navegar entre páginas y ajustar el zoom del texto.
// La aplicación está diseñada para ser intuitiva, permitiendo al usuario cargar un PDF, traducirlo y navegar por sus páginas con facilidad. También implementa un sistema de caché para optimizar el rendimiento y evitar traducciones repetidas.